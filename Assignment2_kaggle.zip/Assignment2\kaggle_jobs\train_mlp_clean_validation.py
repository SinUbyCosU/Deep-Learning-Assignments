"""MLP baseline with a clean validation split (default: CIFAR-10)."""

import os

from Assignmnt2 import ExperimentConfig, run_experiment


def main() -> None:
    dataset = os.environ.get("MLP_DATASET", "cifar10").lower()
    config = ExperimentConfig(
        dataset=dataset,
        model="mlp",
        epochs=int(os.environ.get("EPOCHS", 20)),
        batch_size=int(os.environ.get("BATCH_SIZE", 256)),
        lr=float(os.environ.get("LR", 1e-3)),
        weight_decay=float(os.environ.get("WEIGHT_DECAY", 1e-4)),
        val_split=float(os.environ.get("VAL_SPLIT", 0.2)),
        corruption_types=None,
        use_corrupted_validation=False,
        log_dir=os.environ.get("LOG_DIR", f"results/{dataset}_mlp_clean"),
        split_dir=os.environ.get("SPLIT_DIR", "splits"),
        data_dir=os.environ.get("DATA_DIR", "data"),
        num_workers=int(os.environ.get("NUM_WORKERS", 4)),
        seed=int(os.environ.get("SEED", 123)),
    )
    run_experiment(config)


if __name__ == "__main__":
    main()
