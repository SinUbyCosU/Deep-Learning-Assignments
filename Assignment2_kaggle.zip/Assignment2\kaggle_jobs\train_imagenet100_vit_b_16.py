"""Train ViT-B/16 on ImageNet-100."""

import os

from Assignmnt2 import ExperimentConfig, run_experiment


def main() -> None:
    imagenet_root = os.environ.get("IMAGENET100_ROOT", "/kaggle/input/imagenet100")
    config = ExperimentConfig(
        dataset="imagenet100",
        model="vit_b_16",
        epochs=int(os.environ.get("EPOCHS", 30)),
        batch_size=int(os.environ.get("BATCH_SIZE", 128)),
        lr=float(os.environ.get("LR", 3e-4)),
        weight_decay=float(os.environ.get("WEIGHT_DECAY", 5e-4)),
        val_split=float(os.environ.get("VAL_SPLIT", 0.2)),
        corruption_severity=int(os.environ.get("CORRUPTION_SEVERITY", 2)),
        log_dir=os.environ.get("LOG_DIR", "results/imagenet100_vit_b_16"),
        split_dir=os.environ.get("SPLIT_DIR", "splits"),
        data_dir=os.environ.get("DATA_DIR", "data"),
        imagenet_root=imagenet_root,
        num_workers=int(os.environ.get("NUM_WORKERS", 8)),
        seed=int(os.environ.get("SEED", 42)),
    )
    run_experiment(config)


if __name__ == "__main__":
    main()
