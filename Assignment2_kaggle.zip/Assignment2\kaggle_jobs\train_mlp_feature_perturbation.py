"""MLP training with feature-map perturbation instead of corrupting validation."""

import os

from Assignmnt2 import ExperimentConfig, run_experiment


def main() -> None:
    dataset = os.environ.get("MLP_DATASET", "cifar10").lower()
    feature_hook = os.environ.get("FEATURE_HOOK", "1")
    feature_noise_std = float(os.environ.get("FEATURE_NOISE_STD", 0.1))
    config = ExperimentConfig(
        dataset=dataset,
        model="mlp",
        epochs=int(os.environ.get("EPOCHS", 20)),
        batch_size=int(os.environ.get("BATCH_SIZE", 256)),
        lr=float(os.environ.get("LR", 1e-3)),
        weight_decay=float(os.environ.get("WEIGHT_DECAY", 1e-4)),
        val_split=float(os.environ.get("VAL_SPLIT", 0.2)),
        feature_hook=feature_hook,
        feature_noise_std=feature_noise_std,
        log_dir=os.environ.get("LOG_DIR", f"results/{dataset}_mlp_feature_noise"),
        split_dir=os.environ.get("SPLIT_DIR", "splits"),
        data_dir=os.environ.get("DATA_DIR", "data"),
        num_workers=int(os.environ.get("NUM_WORKERS", 4)),
        seed=int(os.environ.get("SEED", 456)),
    )
    run_experiment(config)


if __name__ == "__main__":
    main()
