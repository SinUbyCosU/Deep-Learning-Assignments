"""MLP training where validation corruptions are optimized to match target drop."""

import os

from Assignmnt2 import ExperimentConfig, run_mlp_validation_regimes


def main() -> None:
    dataset = os.environ.get("MLP_DATASET", "cifar10").lower()
    base_config = ExperimentConfig(
        dataset=dataset,
        model="mlp",
        epochs=int(os.environ.get("EPOCHS", 20)),
        batch_size=int(os.environ.get("BATCH_SIZE", 256)),
        lr=float(os.environ.get("LR", 1e-3)),
        weight_decay=float(os.environ.get("WEIGHT_DECAY", 1e-4)),
        val_split=float(os.environ.get("VAL_SPLIT", 0.2)),
        use_corrupted_validation=True,
        optimize_validation_corruption=True,
        corruption_types=None,
        corruption_severity=int(os.environ.get("CORRUPTION_SEVERITY", 2)),
        log_dir=os.environ.get("LOG_DIR", f"results/{dataset}_mlp_optimized"),
        split_dir=os.environ.get("SPLIT_DIR", "splits"),
        data_dir=os.environ.get("DATA_DIR", "data"),
        num_workers=int(os.environ.get("NUM_WORKERS", 4)),
        seed=int(os.environ.get("SEED", 123)),
    )
    run_mlp_validation_regimes(base_config, regime_filter=["optimized"])


if __name__ == "__main__":
    main()
